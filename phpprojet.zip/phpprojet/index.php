<?php
    include_once('php/const.php');

    include_once("./template/head.inc.php");

?>
<body>

	<ul>
		<li><a href="index.php?page=1">&lt;/&gt;  L'école</a></li>
		<li><a href="index.php?page=2">&lt;/&gt; Formations</a></li>
		<li><a href="index.php?page=3">&lt;/&gt;  Contact</a></li>
		
	</ul>
	<main>
		<h1><?php print titre ?></h1>

	
			<?php
				include_once('php/root.php');
			?>
    </main>

    <footer>
        <p> <?php print footer?></p>
    </footer>
</body>

</html>