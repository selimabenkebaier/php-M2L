
<section>
	<h2>Présentation</h2>
		<p>
			Depuis sa création en 1984, l’EDW a choisi de s’implanter dans des villes créatives et 
			dynamiques. Présente sur 5 campus en France (Paris, Bordeaux, Aix-en-Provence, Nantes, Lille) 
			et 6 à l’étranger (dont 4 campus membres du réseau AD Education*), l’EDW est 
			l’école de référence dans les secteurs du Design, du Digital, de l’Animation et du Jeu vidéo.
		</p>
</section>
<div class="grid-img">
	<h2>Nos compus en France</h2>
	<ul>
		<li><img src="./asset/ambiance_01.jpg" alt="Paris" /></li>
		<li><img src="./asset/nantes.jpg" alt="Nantes" /></li>
		<li><img src="./asset/bordeaux.jpg" alt="Bordeaux" /></li>
	</ul>
</div>
<!--icones-->
<div class="grid-icone">
	<h2>Nous suivre</h2>
	<ul>
		<li><img src="./icones/logo_facebook_3225194.png" alt="FB" /></li>
		<li><img src="./icones/logo_twitter_3225183.png" alt="Instagram" /></li>
		<li><img src="./icones/logo_instagram_3225191.png" alt="Instagram" /></li>
		<li><img src="./icones/logo_linkedin_3225190.png" alt="Instagram" /></li>
	</ul>
</div>
