<section>
	<h2>Cursus &amp; formations</h2>
		<p>Tous nos cursus tournent au tour du développement web et application. Vous trouverez pour vos choix 
			toutes les informations ci-dessous :
		</p>
	<h2>Développement &amp; web-design</h2>
		<ul>
			<li>Développeur front : html, css et Ecmascript 6, 7, 8. 400H</li>
			<li>Développeur back : php et SQL 300H</li>
			<li>Webdesign : UX et créa 200H</li>
			<li>Webmarketing : 150H</li>
		</ul>
</section>
<div class="grid-img">
	<h2>Nos formations</h2>
	<ul>
		<li><img src="./asset/bachelor-ecv-game-jeu.jpg" alt="bachelor_jeu" /></li>
		<li><img src="./asset/nina_bouchaud_1-390x390.jpg" alt="bachelor" /></li>
		<li><img src="./asset/bachelor-en-design-pack-2-1.jpg" alt="bachelor_design" /></li>
	</ul>
</div>