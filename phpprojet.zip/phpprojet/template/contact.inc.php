
<section>
	<h2>Contact</h2>
		<form action="#" method="post">
			<label for="cursus">Cursus</label>
			<input type="text" name="cursus" id="cursus" placeholder="Cursus" required aria-required="true" autofocus="true">

			<label for="prenom">Votre Prénom</label>
			<input type="text" name="prenom" id="prenom" placeholder="Prénom" required aria-required="true">

            <label for="nom">Votre nom</label>
            <input type="text" name="nom" id="nom" placeholder="Nom" required aria-required="true">

            <label for="tel">+33 </label>
            <input type="number" name="tel" id="tel" placeholder="Téléphone" required aria-required="true">

			<label for="mail">Votre Mail</label>
			<input type="email" name="mail" id="mail" placeholder="Email" required aria-required="true">

			<label for="etudes">Votre message</label>
            <input type="text" name="etudes" id="etudes" placeholder="Votre niveau d'études" required aria-required="true">


            <label for="etudes">Je souhaite prendre un RDV d'admission (en option)</label>
            <input type="checkbox" name="etudes" id="etudes">


            <label for="etudes">Je souhaite recevoir une brochure par courrier (en option)</label>
            <input type="checkbox" name="etudes" id="etudes">


            <label for="etudes">Dans le cadre...</label>
            <input type="checkbox" name="etudes" id="etudes" placeholder="Votre niveau d'études" required aria-required="true">

			<input type="submit" value="Envoyer">
			
		</form>
</section>