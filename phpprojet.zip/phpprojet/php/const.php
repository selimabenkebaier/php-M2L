<?php

const titre ="M2L Maison de ligue de lorraine";
const css="";
const footer="&copy - EDW - 2020";